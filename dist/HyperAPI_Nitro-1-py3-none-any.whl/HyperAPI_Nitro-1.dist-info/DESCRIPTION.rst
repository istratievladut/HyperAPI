HyperCube API for Nitro


