from HyperAPI.hdp_api.routes.base.resource_base import Resource
from HyperAPI.hdp_api.routes.base.route_base import Route
from HyperAPI.hdp_api.routes.base.version_management import deprecated_since, available_since, reroute
